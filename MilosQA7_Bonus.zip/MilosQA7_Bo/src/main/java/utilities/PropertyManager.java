package utilities;

import java.io.FileInputStream;
import java.util.Properties;

public class PropertyManager {
    private static String reg_first_name;
    private static String url;
    private static String driver_path;
    private static String reg_last_name;
    private static String reg_email;
private static String phone;
private static String password;
    public static PropertyManager getInstance() {


        Properties prop = new Properties();
        PropertyManager instance = new PropertyManager();
        try {
            FileInputStream configuration = new
                    FileInputStream("src/main/resources/configuration.properties");
            prop.load(configuration);

        } catch (Exception e) {
            e.printStackTrace();
        }
        password=prop.getProperty("password");
        phone= prop.getProperty("phone");
        reg_email= prop.getProperty("reg_email");
        reg_last_name= prop.getProperty("reg_last_name");
        reg_first_name=prop.getProperty("reg_first_name");
        driver_path=prop.getProperty("driver_path");
        url = prop.getProperty("url");
        return instance;

    }

    public static String getUrl() {
        return url;
    }
    public static String getDriverPath(){
        return driver_path;
    }
    public static String getRegFirName(){return reg_first_name;}
    public static String getRegLasName(){return reg_last_name;}
    public static String getRegEmail(){return reg_email;}
    public static String getPhone(){return phone;}
    public static String getPass(){return password;}
}
