package methods;

import org.openqa.selenium.WebDriver;
import pages.CameraMenuPage;


public class CameraMenuPageMethods extends CameraMenuPage {
    public CameraMenuPageMethods(WebDriver driver) {
        super(driver);
    }



       public CameraMenuPageMethods addRemoveItemFromCart() {

           clickAddCartCannonCamera();
           clickCartList();
           clickRemoveButtonCartList();
           //clickCartList();
           return this;
       }


}

