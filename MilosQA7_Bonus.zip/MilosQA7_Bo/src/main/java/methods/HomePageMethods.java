package methods;

import org.openqa.selenium.WebDriver;
import pages.HomePage;

public class HomePageMethods extends HomePage {
              public HomePageMethods(WebDriver driver) {
              super(driver);}




                    public HomePageMethods navigateToLogin(){
                         clickMyAccount();
                         clickDropLogin();
                         return this;

                    }
                    public HomePageMethods navigateToRegister(){
                          clickMyAccount();
                          clickDropRegister();
                          return this;
                    }
                    public HomePageMethods logout(){
                          clickMyAccount();
                          clickDropLogout();
                          return this;
                    }
}
