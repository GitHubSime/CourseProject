package methods;

import org.openqa.selenium.WebDriver;
import pages.LoginPage;

public class LoginPageMethods extends LoginPage {
             public LoginPageMethods(WebDriver driver) {
             super(driver);}


           public LoginPageMethods login (String email,String password) {

           writeEmail(email);
           writePassword(password);
           clickLoginButton();
           return this;}
    }






