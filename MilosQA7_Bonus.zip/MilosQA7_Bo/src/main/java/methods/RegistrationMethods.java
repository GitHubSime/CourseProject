package methods;

import org.openqa.selenium.WebDriver;
import pages.RegistrationFormPage;


public class RegistrationMethods extends RegistrationFormPage {
    public RegistrationMethods(WebDriver driver) {
        super(driver);}



    public RegistrationMethods writeRegistrationForm(String first_name, String last_name, String email, String phone
                , String password, String confpassword) {
            writeFirstName(first_name);
            writeLastName(last_name);
            writeEmail(email);
            writePhone(phone);
            writePass(password);
            writeConfPass(confpassword);
            clickReadPrivacy();
            clickContinue();
            return this;

        }

    }









