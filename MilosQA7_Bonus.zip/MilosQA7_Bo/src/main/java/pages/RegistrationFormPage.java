package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegistrationFormPage extends BasePage {
    public RegistrationFormPage(WebDriver driver) {
        super(driver);
    }


    By firstNameFieldBy = By.id("input-firstname");
    By lastNameFieldBy = By.id("input-lastname");
    By emailFieldBy = By.id("input-email");
    By phoneFieldBy = By.id("input-telephone");
    By passFieldBy = By.id("input-password");
    By confPassFieldBy = By.id("input-confirm");
    By readPrivacyButtonBy = By.xpath("//input[@name=\"agree\"]");
    By continueButtonBy=By.xpath("//input[@value=\"Continue\"]");

    public RegistrationFormPage clickReadPrivacy() {
        click(readPrivacyButtonBy);
        return this;
    }

    public RegistrationFormPage writeFirstName(String text) {
        writeText(firstNameFieldBy, text);
        return this;
    }

    public RegistrationFormPage writeLastName(String text) {
        writeText(lastNameFieldBy, text);
        return this;
    }

    public RegistrationFormPage writeEmail(String text) {
        writeText(emailFieldBy, text);
        return this;
    }

    public RegistrationFormPage writePhone(String text) {
        writeText(phoneFieldBy, text);
        return this;
    }

    public RegistrationFormPage writePass(String text) {
        writeText(passFieldBy, text);
        return this;
    }

    public RegistrationFormPage writeConfPass(String text) {
        writeText(confPassFieldBy, text);
        return this;
    }
    public RegistrationFormPage clickContinue(){
        click(continueButtonBy);
        return this;
    }
}
