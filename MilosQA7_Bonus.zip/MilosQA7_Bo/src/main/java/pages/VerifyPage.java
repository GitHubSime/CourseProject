package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

 public class VerifyPage extends BasePage {
     public VerifyPage(WebDriver driver) {
         super(driver);
     }
     //x path find by visible text
     By errorNotificationBy = By.xpath("//*[text()=' Warning: No match for E-Mail Address and/or Password.']");
     By confirmationNoticeBy=By.xpath("//*[contains(text(),'Congratulations! Your new account has been successfully created!')]");
     By logOutButton= By.linkText("Logout");
     By loginDropButton=By.linkText("Login");
     By emptyCartListBy=By.xpath("//span[@id = 'cart-total']");


     public VerifyPage verifyFailedLogin(String expectedText) {
         String alert = readText(errorNotificationBy);
         assertStringEquals(alert, expectedText);
         return this;}

         public VerifyPage verifyUserRegister (String expectedText) {
         String notice=readText(confirmationNoticeBy);
         assertStringEquals(notice,expectedText);
         return this;}

     public VerifyPage verifyLogin(String expectedText){
         String register=readText(logOutButton);
         assertStringEquals(register,expectedText);
         return this;
     }
     public VerifyPage verifyLogout(String expectedText) {
         String sign_in = readText(loginDropButton);
         assertStringEquals(sign_in, expectedText);
         return this;
     }



     public VerifyPage verifyRemoveItemFromCart(String expectedText) {
         String item=readText(emptyCartListBy);
         assertStringEquals(item,expectedText);
         return this;

     }

     }



