package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage extends BasePage {
    public HomePage(WebDriver driver) {
        super(driver);}

        By dropDownMyAccountButton = By.className("dropdown");
        //when you have link redirection button use linkText,this text located after link
        By loginDropButton=By.linkText("Login");
        By registerDropButton= By.linkText("Register");
        By logoutDropButton=By.linkText("Logout");
        By cameraMenuButtonBy= By.linkText("Cameras");


        public HomePage clickMyAccount(){
            click(dropDownMyAccountButton);
            return this;
        }

        public HomePage clickDropLogin(){
            click(loginDropButton);
            return this;
        }

        public HomePage clickDropRegister(){
            click(registerDropButton);
            return this;
        }

        public HomePage clickDropLogout(){
            click(logoutDropButton);
            return this;
        }
        public HomePage clickCameraMenu(){
            click(cameraMenuButtonBy);
            return this;
        }

    }

