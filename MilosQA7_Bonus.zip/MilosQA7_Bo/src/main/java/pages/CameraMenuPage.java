package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CameraMenuPage extends BasePage {
    public CameraMenuPage(WebDriver driver) {
        super(driver);}



    // By addCartCannonCameraBy=By.id("//[contains(@onclick,\"cart.add('31', '1');\")]");
    By addCartNikonCameraBy = By.xpath("//button[@type='button'][@onClick=\"cart.add('31', '1');\"]//span[text()='Add to Cart']");
    By cartListButtonBy=By.xpath("//button[@class='btn btn-inverse btn-block btn-lg dropdown-toggle']");
    By removeCartItemButtonBy=By.xpath("//button[@title = 'Remove']");



    public CameraMenuPage clickAddCartCannonCamera(){
        click(addCartNikonCameraBy);
        return this;

    }

    public CameraMenuPage clickCartList(){
        click(cartListButtonBy);
        return this;
    }

    public CameraMenuPage clickRemoveButtonCartList(){
        click(removeCartItemButtonBy);
        return this;

    }
}
