package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage extends BasePage { public LoginPage(WebDriver driver) {
    super(driver);}

// input and value button x path
    By loginButtonBy=By.xpath("//input[@value='Login']");
    By eMailFieldBy=By.id("input-email");
    By passwordFieldBy=By.id("input-password");

    public LoginPage clickLoginButton(){
    click(loginButtonBy);
    return this;
    }
    public LoginPage writeEmail(String email){
        writeText(eMailFieldBy,email);
        return this;
    }
    public LoginPage writePassword(String password){
        writeText(passwordFieldBy,password);
        return this;
    }
}
