package base_test_with_login;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import pages.VerifyPage;

public class LogoutTest extends BaseTestWithLogin {
    public VerifyPage verifyPage;


    @Test

    public void LogoutTest() {


        verifyPage = new VerifyPage(driver);
        homePageMethods.logout();


        try {


            verifyPage.verifyLogout("Login");
            System.out.print("User is  logout");

        } catch (Exception e) {
            Assert.fail("User IS login!");
        }


    }
}
