package base_test_with_login;

import methods.HomePageMethods;
import methods.LoginPageMethods;
import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import tests.BaseTest;
import utilities.PropertyManager;

import java.util.concurrent.TimeUnit;

public class BaseTestWithLogin extends BaseTest  {

    public WebDriver driver;
    public ChromeOptions options;
    public LoginPageMethods logInPageMethods;
    public HomePageMethods homePageMethods;



    @Before
    public void setup(){
        options=new ChromeOptions();
        // disable browser pop ups. They can make test not run properly.
        options.addArguments("--disable-notificationa");


        System.setProperty("webdriver.chrome.driver", PropertyManager.getInstance().getDriverPath());
        String baseURL=PropertyManager.getInstance().getUrl();
        driver=new ChromeDriver(options);

        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        driver.manage().window().maximize();

        logInPageMethods=new LoginPageMethods(driver);
        homePageMethods=new HomePageMethods(driver);


        driver.get(baseURL);
        homePageMethods.navigateToLogin();
        logInPageMethods.login(PropertyManager.getInstance().getRegEmail(),
                PropertyManager.getInstance().getPass());
    }
    @After
    public void teardown (){
        driver.quit();
    }
}

