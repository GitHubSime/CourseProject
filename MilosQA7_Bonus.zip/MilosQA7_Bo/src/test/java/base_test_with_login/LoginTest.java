package base_test_with_login;

import org.junit.Assert;
import org.junit.Test;
import pages.VerifyPage;
import utilities.PropertyManager;

public class LoginTest extends BaseTestWithLogin {


    public VerifyPage verifyPage;

    @Test
    public void LoginTest() {

        verifyPage = new VerifyPage(driver);


        try {


            verifyPage.verifyLogin("Logout");
            System.out.print("User is loged in");

        } catch (Exception e) {
            Assert.fail("User IS Not loged in!");
        }
    }
}
