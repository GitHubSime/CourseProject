package tests;

import methods.HomePageMethods;
import methods.RegistrationMethods;
import org.junit.Assert;
import org.junit.Test;
import pages.VerifyPage;
import utilities.PropertyManager;

public class RegistrationTest extends BaseTest {


    public HomePageMethods homePageMethods;
    public RegistrationMethods registrationMethods;
    public VerifyPage verifyPage;


    @Test
    public void RegistrationTest() {


        homePageMethods = new HomePageMethods(driver);
        registrationMethods = new RegistrationMethods(driver);
        verifyPage = new VerifyPage(driver);

///make data creation-arrays
        homePageMethods.navigateToRegister();
        registrationMethods.writeRegistrationForm(PropertyManager.getInstance().getRegFirName(),
                PropertyManager.getInstance().getRegLasName(),
                PropertyManager.getInstance().getRegEmail(), PropertyManager.getInstance().getPhone(),
                PropertyManager.getInstance().getPass(),
                PropertyManager.getInstance().getPass());

        try {
///find locator for Complete Registration

            verifyPage.verifyUserRegister("Congratulations! Your new account has been successfully created!");
            System.out.print("User is Register");

        } catch (Exception e) {
            Assert.fail("User IS NOT Register!");

        }
    }
}
