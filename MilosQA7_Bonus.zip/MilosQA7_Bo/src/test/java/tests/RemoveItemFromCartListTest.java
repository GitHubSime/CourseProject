package tests;

import methods.CameraMenuPageMethods;
import org.junit.Assert;
import org.junit.Test;
import pages.HomePage;
import pages.VerifyPage;

public class RemoveItemFromCartListTest extends BaseTest {


    public VerifyPage verifyPage;
    public HomePage homePage;
    public CameraMenuPageMethods cameraMenuPageMethods;

    @Test
    public void removeItemFromCartListTest() {

        homePage = new HomePage(driver);
        cameraMenuPageMethods = new CameraMenuPageMethods(driver);
        verifyPage = new VerifyPage(driver);

        homePage.clickCameraMenu();
        cameraMenuPageMethods.addRemoveItemFromCart();


        try {
            verifyPage.verifyRemoveItemFromCart("0 item(s) - $0.00");
            System.out.print("Cart is empty");

        } catch (
                Exception e) {
            Assert.fail("Item is in cart list");


        }
    }
}
