package tests;

import methods.HomePageMethods;
import org.junit.Assert;
import org.junit.Test;
import pages.LoginPage;
import pages.VerifyPage;

public class FailedLoginTest extends BaseTest {

    public HomePageMethods homePageMethods;
    public VerifyPage verifyPage;
    public LoginPage loginPage;

    @Test
    public void FiledLoginTest() {

        homePageMethods = new HomePageMethods(driver);
        verifyPage = new VerifyPage(driver);
        loginPage = new LoginPage(driver);


        homePageMethods.navigateToLogin();
        loginPage.clickLoginButton();


        try {


            verifyPage.verifyFailedLogin("Warning: No match for E-Mail Address and/or Password.");
            System.out.print("User is NOT loged in");

        } catch (Exception e) {
            Assert.fail("User IS loged in!");


        }
    }
}

