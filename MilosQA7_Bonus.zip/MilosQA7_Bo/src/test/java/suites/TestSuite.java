package  suites;


import base_test_with_login.LoginTest;
import base_test_with_login.LogoutTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import tests.*;


@RunWith(Suite.class)

@Suite.SuiteClasses({
        RegistrationTest.class,
        FailedLoginTest.class,
        LoginTest.class,
        LogoutTest.class,
        EmptyPasswordFailedLoginTest.class,
        EmptyUserNameFailedLoginTest.class,
        RemoveItemFromCartListTest.class,

})

public class TestSuite {
}